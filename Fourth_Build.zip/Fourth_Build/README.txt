Thanks for Playing

Now go blast some Robots

If possible, please try running through the game a few times.

When done, please copy and send the "Text" folder in "Assets/Resources" to me by uploading to the given Google Drive link

https://drive.google.com/drive/folders/1AFTu_dHk3HXQ564HawAQnF4Sa9ez1p4E?usp=sharing